final interface Demo
{
  protected int m1();
  public final void m2();
  protected final int x = 10;
}

class test implements Demo
{    
  public static void main(String[] args)
  {
    test obj = new test();
  }
}
